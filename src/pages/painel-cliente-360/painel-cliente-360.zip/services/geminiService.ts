

import { GoogleGenAI, Type, Chat, GenerateContentResponse } from "@google/genai";
import { Customer, StrategicInsight, CustomerStatus, CategorizedRecommendation, ChurnPrediction, CustomerSegment } from "../types";

// Check if the API key is available. If not, the service will run in demo mode.
const apiKey = process.env.API_KEY;
const isApiKeyAvailable = !!apiKey;

// Initialize the AI client only if the key is available.
const ai = isApiKeyAvailable ? new GoogleGenAI({ apiKey }) : null;

// --- MOCK IMPLEMENTATIONS FOR DEMO MODE ---

/**
 * Simulates a delay to make mock responses feel more realistic.
 */
const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * A mock function that generates realistic strategic insights for demo purposes.
 */
const mockGenerateStrategicInsights = async (): Promise<StrategicInsight> => {
    await sleep(1500); // Simulate network latency
    return {
        trends: [
            "Um número significativo de clientes 'Novos' parece não interagir após o cadastro inicial, elevando o risco de churn precoce.",
            "Clientes com gastos mais altos ('Ativo') mantêm um padrão de engajamento estável, representando a espinha dorsal da receita."
        ],
        recommendations: [
            { recommendation: "Implementar uma campanha de e-mail de boas-vindas com um guia de primeiros passos para novos clientes.", category: 'Quick Win' },
            { recommendation: "Criar um programa de fidelidade com recompensas exclusivas para clientes de alto valor para aumentar a retenção.", category: 'Strategic Shift' },
            { recommendation: "Analisar o feedback de clientes 'Cancelados' para identificar pontos de atrito no serviço.", category: 'Data Analysis' }
        ]
    };
};

/**
 * A mock chat session that simulates streaming responses for a specific customer.
 */
const mockCreateCustomerChatSession = (customer: Customer): Chat => {
    // This is an async generator function that simulates the `sendMessageStream` method.
    const sendMessageStream = async function* (params: { message: string }): AsyncGenerator<GenerateContentResponse> {
        await sleep(500); // Simulate model thinking time

        const lowerCaseMessage = params.message.toLowerCase();
        let responseText = "";
        
        const initialAnalysisMarker = 'análise inicial';
        const suggestionMarker = '[SUGGESTIONS]';

        if (lowerCaseMessage.includes(initialAnalysisMarker)) {
            const riskLevel = customer.status === 'Em Risco' || customer.status === 'Cancelado' ? 'Alto' : (customer.status === 'Novo' ? 'Médio' : 'Baixo');
            responseText = `**Análise de Demonstração:**
- **Resumo:** ${customer.name} é um cliente com status **'${customer.status}'**. Seu engajamento mais recente foi ${customer.lastSeen}.
- **Nível de Risco:** ${riskLevel}.
- **Ações Sugeridas:** 
  1. (Exemplo) Enviar um e-mail de acompanhamento personalizado.
  2. (Exemplo) Adicionar a uma campanha de marketing relevante.

${suggestionMarker}
Qual foi a última compra?
Resuma o histórico de interação.
Elabore um e-mail de reengajamento.`;
        } else if (lowerCaseMessage.includes("gasto") || lowerCaseMessage.includes("spend")) {
            responseText = `O gasto total registrado para ${customer.name} é de R$${customer.totalSpend.toLocaleString('pt-BR')}.`;
        } else if (lowerCaseMessage.includes("status")) {
             responseText = `O status atual de ${customer.name} é **${customer.status}**.`;
        } else {
            responseText = "Sou uma IA de demonstração. Minhas respostas são pré-definidas. Em um ambiente de produção, eu poderia analisar dados em tempo real e responder a perguntas complexas sobre o histórico de compras, engajamento e muito mais. Tente perguntar sobre 'status' ou 'gasto total'.";
        }

        // Simulate streaming by yielding words one by one.
        const words = responseText.split(/(\s+)/); // Split by spaces, keeping them
        for (const word of words) {
            yield { text: word } as GenerateContentResponse;
            await sleep(50);
        }
    };

    // We return an object that mimics the `Chat` interface.
    return {
        sendMessageStream,
    } as unknown as Chat;
};

const mockPredictChurningCustomers = async (customers: Customer[]): Promise<ChurnPrediction[]> => {
    await sleep(1800);
    const atRiskCustomers = customers.filter(c => c.status === CustomerStatus.AtRisk);
    if (atRiskCustomers.length === 0) return [];
    
    return atRiskCustomers.slice(0, 4).map((c, i) => ({
        customerId: c.id,
        customerName: c.name,
        customerAvatar: c.avatar,
        churnProbability: 0.75 - (i * 0.1), // e.g., 75%, 65%, 55% ...
    })).sort((a,b) => b.churnProbability - a.churnProbability);
};

const mockSegmentCustomers = async (customers: Customer[]): Promise<CustomerSegment[]> => {
    await sleep(2200);
    const activeHighSpenders = customers.filter(c => c.status === CustomerStatus.Active && c.totalSpend > 2000);
    const atRiskCustomers = customers.filter(c => c.status === CustomerStatus.AtRisk);
    const newCustomers = customers.filter(c => c.status === CustomerStatus.New);

    return [
        {
            segmentName: "Campeões de Engajamento",
            description: "Clientes leais e de alto valor que interagem regularmente. A base da sua receita.",
            customerCount: activeHighSpenders.length,
            personas: activeHighSpenders.slice(0,2).map(c => c.name),
        },
        {
            segmentName: "Gigantes Adormecidos",
            description: "Clientes que não interagem há algum tempo e correm o risco de cancelar. Potencial de reengajamento.",
            customerCount: atRiskCustomers.length,
            personas: atRiskCustomers.slice(0,2).map(c => c.name),
        },
         {
            segmentName: "Novos e promissores",
            description: "Clientes recém-adquiridos com potencial de crescimento. A fase de onboarding é crítica.",
            customerCount: newCustomers.length,
            personas: newCustomers.slice(0,2).map(c => c.name),
        },
    ].filter(s => s.customerCount > 0);
};

// --- SCHEMA DEFINITIONS ---

const strategicInsightSchema = {
    type: Type.OBJECT,
    properties: {
        trends: {
            type: Type.ARRAY,
            items: {
                type: Type.STRING
            },
            description: "Identifique 1-2 tendências principais do resumo de dados de clientes fornecido. Por exemplo: 'Um número significativo de novos clientes está em risco.'"
        },
        recommendations: {
            type: Type.ARRAY,
            description: "Forneça 2-3 recomendações estratégicas de alto nível com base nas tendências identificadas.",
            items: {
                type: Type.OBJECT,
                properties: {
                    recommendation: {
                        type: Type.STRING,
                        description: "A recomendação acionável."
                    },
                    category: {
                        type: Type.STRING,
                        description: "A categoria da recomendação.",
                        enum: ['Quick Win', 'Strategic Shift', 'Data Analysis']
                    }
                },
                required: ["recommendation", "category"]
            }
        }
    },
    required: ["trends", "recommendations"]
};

const churnPredictionSchema = {
    type: Type.ARRAY,
    description: "Lista de até 5 clientes com maior probabilidade de churn.",
    items: {
        type: Type.OBJECT,
        properties: {
            customerId: { type: Type.NUMBER, description: "O ID do cliente." },
            customerName: { type: Type.STRING, description: "O nome do cliente." },
            customerAvatar: { type: Type.STRING, description: "A URL do avatar do cliente." },
            churnProbability: { type: Type.NUMBER, description: "A probabilidade de churn, de 0.0 a 1.0." },
        },
        required: ["customerId", "customerName", "customerAvatar", "churnProbability"]
    }
};

const customerSegmentationSchema = {
    type: Type.ARRAY,
    description: "Uma lista de 2-3 segmentos de clientes identificados.",
    items: {
        type: Type.OBJECT,
        properties: {
            segmentName: { type: Type.STRING, description: "O nome do segmento (ex: 'Campeões de Engajamento')." },
            description: { type: Type.STRING, description: "Uma breve descrição do segmento." },
            customerCount: { type: Type.NUMBER, description: "O número de clientes neste segmento." },
            personas: { 
                type: Type.ARRAY, 
                items: { type: Type.STRING },
                description: "Dois ou três exemplos de nomes de clientes que se encaixam neste segmento."
            },
        },
        required: ["segmentName", "description", "customerCount", "personas"]
    }
};


// --- PUBLIC API FUNCTIONS ---

/**
 * Creates a chat session. If an API key is available, it connects to Gemini.
 * Otherwise, it returns a mock chat session for demonstration.
 */
export const createCustomerChatSession = (customer: Customer): Chat => {
    if (!isApiKeyAvailable) {
        console.warn("API_KEY not found. Running chat in demo mode.");
        return mockCreateCustomerChatSession(customer);
    }

    const { name, status, totalSpend, lastSeen, joinDate } = customer;
    const systemInstruction = `
        Você é um assistente de CRM (Customer Relationship Management) inteligente, prestativo e amigável.
        Sua tarefa é fornecer insights e responder a perguntas sobre um cliente específico com base nos dados fornecidos.
        Seja sempre conciso e direto ao ponto. Responda em português.
        
        DADOS DO CLIENTE ATUAL:
        - Nome: ${name}
        - Status: ${status}
        - Gasto Total: R$${totalSpend}
        - Visto por Último: ${lastSeen}
        - Data de Cadastro: ${joinDate}

        Não mencione que você tem esses dados, apenas os use para responder às perguntas.
        Por exemplo, se o usuário perguntar "qual o status dele?", responda apenas "${status}".
    `;

    const chat = ai!.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction,
        },
    });
    return chat;
};


/**
 * Generates strategic insights. If an API key is available, it connects to Gemini.
 * Otherwise, it returns mock insights for demonstration.
 */
export const generateStrategicInsights = async (customers: Customer[]): Promise<StrategicInsight> => {
    if (!isApiKeyAvailable) {
         console.warn("API_KEY not found. Running strategic insights in demo mode.");
        return mockGenerateStrategicInsights();
    }

    // Create a summary of the customer data to send to the model
    const totalCustomers = customers.length;
    const statusCounts = customers.reduce((acc, customer) => {
        acc[customer.status] = (acc[customer.status] || 0) + 1;
        return acc;
    }, {} as Record<CustomerStatus, number>);

    const prompt = `
        Analise o seguinte resumo de um banco de dados de clientes. Com base nesses dados, forneça as principais tendências e recomendações estratégicas em português.
        Para cada recomendação, classifique-a em uma das seguintes categorias: 'Quick Win' (ação de baixo esforço e alto impacto), 'Strategic Shift' (iniciativa de longo prazo) ou 'Data Analysis' (requer mais investigação).

        Resumo dos Dados:
        - Total de Clientes: ${totalCustomers}
        - Clientes Ativos: ${statusCounts.Ativo || 0}
        - Clientes em Risco: ${statusCounts['Em Risco'] || 0}
        - Clientes Cancelados: ${statusCounts.Cancelado || 0}
        - Novos Clientes: ${statusCounts.Novo || 0}
        - Métricas de receita total e outras métricas financeiras não são fornecidas, foque na distribuição de status dos clientes.
    `;
    
    try {
        const response = await ai!.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: strategicInsightSchema,
            }
        });

        const jsonText = response.text.trim();
        const parsedJson = JSON.parse(jsonText);

        // Type assertion to ensure the parsed data matches our interface
        const strategicInsights: StrategicInsight = {
            trends: parsedJson.trends,
            recommendations: parsedJson.recommendations as CategorizedRecommendation[],
        };

        return strategicInsights;

    } catch (error) {
        console.error("Error generating strategic insights from Gemini:", error);
        throw new Error("Falha ao gerar insights estratégicos.");
    }
};

export const predictChurningCustomers = async (customers: Customer[]): Promise<ChurnPrediction[]> => {
    if (!isApiKeyAvailable) {
        console.warn("API_KEY not found. Running churn prediction in demo mode.");
        return mockPredictChurningCustomers(customers);
    }

    const customerSummary = customers.map(c => 
        `ID: ${c.id}, Nome: ${c.name}, Status: ${c.status}, Gasto: ${c.totalSpend}, Visto por último: ${c.lastSeen}, Avatar: ${c.avatar}`
    ).join('\n');

    const prompt = `
        Com base na seguinte lista de clientes, identifique os 5 clientes com a maior probabilidade de churn.
        Considere fatores como status 'Em Risco', tempo desde a última visita ('Visto por último'), e baixo gasto em comparação com o tempo de cadastro.
        Forneça uma probabilidade de churn para cada um (um número de 0.0 a 1.0).
        Retorne a resposta no formato JSON especificado.

        Dados dos Clientes:
        ${customerSummary}
    `;

    try {
        const response = await ai!.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: churnPredictionSchema,
            }
        });
        return JSON.parse(response.text.trim()) as ChurnPrediction[];
    } catch (error) {
        console.error("Error predicting churn from Gemini:", error);
        throw new Error("Falha ao prever clientes em risco de churn.");
    }
};

export const segmentCustomers = async (customers: Customer[]): Promise<CustomerSegment[]> => {
    if (!isApiKeyAvailable) {
        console.warn("API_KEY not found. Running customer segmentation in demo mode.");
        return mockSegmentCustomers(customers);
    }
    
    const customerSummary = customers.map(c => 
        `Nome: ${c.name}, Status: ${c.status}, Gasto: ${c.totalSpend}, Visto por último: ${c.lastSeen}`
    ).join('\n');

    const prompt = `
        Analise a seguinte lista de clientes e segmente-os em 2-3 personas ou grupos distintos.
        Para cada segmento, forneça um nome criativo, uma breve descrição, o número de clientes que se encaixam nele, e 2-3 nomes de exemplo.
        Baseie a segmentação em padrões de status, gasto e engajamento (visto por último).
        Exemplos de nomes de segmento: 'Campeões de Alto Valor', 'Potenciais em Risco', 'Novos Exploradores'.
        Retorne a resposta no formato JSON especificado.

        Dados dos Clientes:
        ${customerSummary}
    `;

    try {
        const response = await ai!.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: customerSegmentationSchema,
            }
        });
        return JSON.parse(response.text.trim()) as CustomerSegment[];
    } catch (error) {
        console.error("Error segmenting customers from Gemini:", error);
        throw new Error("Falha ao segmentar clientes.");
    }
};