
import React from 'react';
import { NavLink } from 'react-router-dom';
import { IconDashboard, IconSettings } from '../constants';

interface HeaderProps {
  searchTerm: string;
  onSearchChange: (term: string) => void;
}

const Header: React.FC<HeaderProps> = ({ searchTerm, onSearchChange }) => {
    const linkClasses = "flex items-center px-3 py-2 text-text-on-sidebar/70 hover:bg-ui-sidebar-surface rounded-lg transition-colors duration-200";
    const activeLinkClasses = "bg-success text-gray-900 font-bold";

    return (
        <header className="fixed top-0 left-0 right-0 bg-ui-sidebar z-40 p-4 shadow-lg border-b border-border">
            <div className="flex items-center justify-between max-w-screen-2xl mx-auto">
                {/* Left Section: Logo & Nav */}
                <div className="flex items-center space-x-8">
                    <div className="flex items-center">
                        <div className="bg-success p-2 rounded-lg">
                            <i className="fas fa-bullseye text-gray-900"></i>
                        </div>
                        <h1 className="text-xl font-bold ml-3 text-text-on-sidebar">Cliente360</h1>
                    </div>
                    <nav className="hidden md:flex items-center space-x-2">
                         <NavLink to="/" className={({ isActive }) => `${linkClasses} ${isActive ? activeLinkClasses : ''}`}>
                            <IconDashboard />
                            <span className="ml-3">Painel</span>
                        </NavLink>
                        <NavLink to="/settings" className={({ isActive }) => `${linkClasses} ${isActive ? activeLinkClasses : ''}`}>
                            <IconSettings />
                            <span className="ml-3">Configurações</span>
                        </NavLink>
                    </nav>
                </div>

                {/* Right Section: Search */}
                <div className="w-full max-w-xs">
                    <div className="relative">
                        <input
                            type="text"
                            placeholder="Buscar clientes..."
                            className="w-full bg-ui-sidebar-surface border border-border/20 rounded-lg py-2 pl-4 pr-10 text-text-on-sidebar placeholder-text-on-sidebar/50 focus:outline-none focus:ring-2 focus:ring-success"
                            value={searchTerm}
                            onChange={(e) => onSearchChange(e.target.value)}
                            aria-label="Buscar clientes"
                        />
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 absolute right-3 top-1/2 -translate-y-1/2 text-text-on-sidebar/50" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Header;
