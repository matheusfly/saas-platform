

import React, { useMemo } from 'react';
import { Customer, CustomerStatus, RevenueByStatus } from '../types';
import { IconDollar, IconCalculator } from '../constants';

interface FinancialSummaryProps {
    customers: Customer[];
}

const statusConfig: Record<CustomerStatus, { color: string; label: string }> = {
    [CustomerStatus.Active]: { color: 'bg-chart-green', label: 'Ativos' },
    [CustomerStatus.AtRisk]: { color: 'bg-chart-yellow', label: 'Em Risco' },
    [CustomerStatus.Churned]: { color: 'bg-chart-red', label: 'Cancelados' },
    [CustomerStatus.New]: { color: 'bg-chart-blue', label: 'Novos' },
};

const FinancialSummary: React.FC<FinancialSummaryProps> = ({ customers }) => {
    const financialData = useMemo(() => {
        if (!customers || customers.length === 0) {
            return {
                totalRevenue: 0,
                arpu: 0,
                revenueByStatus: {},
            };
        }

        const totalRevenue = customers.reduce((sum, c) => sum + c.totalSpend, 0);
        const totalCustomers = customers.length;
        const arpu = totalCustomers > 0 ? totalRevenue / totalCustomers : 0;

        const revenueByStatus = customers.reduce((acc, customer) => {
            if (!acc[customer.status]) {
                acc[customer.status] = 0;
            }
            acc[customer.status]! += customer.totalSpend;
            return acc;
        }, {} as RevenueByStatus);
        
        return { totalRevenue, arpu, revenueByStatus };
    }, [customers]);

    const { totalRevenue, arpu, revenueByStatus } = financialData;

    return (
        <div className="bg-ui-surface p-6 rounded-2xl shadow-lg border border-border">
            <div>
                <div className="flex justify-between items-start mb-4">
                    <div>
                        <p className="text-sm font-medium text-text-secondary">Receita Total</p>
                        <p className="text-3xl font-bold text-text-default mt-1">R${totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                    </div>
                    <div className="bg-primary text-text-on-primary p-3 rounded-full">
                        <IconDollar />
                    </div>
                </div>

                 <div className="flex items-center text-sm mb-6">
                     <div className="bg-ui-sidebar-surface p-2 rounded-lg mr-3">
                        <IconCalculator />
                     </div>
                     <div>
                        <p className="font-semibold text-text-default">R${arpu.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                        <p className="text-xs text-text-secondary">Receita Média por Cliente (ARPU)</p>
                     </div>
                </div>

                <div>
                    <h3 className="text-sm font-semibold text-text-secondary mb-2">Receita por Status</h3>
                    <div className="space-y-2">
                        {Object.entries(revenueByStatus)
                            .sort(([_, a], [__, b]) => b - a)
                            .map(([status, revenue]) => {
                                const percentage = totalRevenue > 0 ? (revenue / totalRevenue) * 100 : 0;
                                const config = statusConfig[status as CustomerStatus];
                                if (!config || revenue === 0) return null;

                                return (
                                    <div key={status}>
                                        <div className="flex justify-between items-center text-xs mb-1">
                                            <span className="font-semibold text-text-default">{config.label}</span>
                                            <span className="text-text-secondary">R${revenue.toLocaleString('pt-BR')}</span>
                                        </div>
                                        <div className="bg-ui-sidebar-surface rounded-full h-2">
                                            <div
                                                className={`${config.color} h-2 rounded-full`}
                                                style={{ width: `${percentage}%` }}
                                                title={`${percentage.toFixed(1)}%`}
                                            ></div>
                                        </div>
                                    </div>
                                );
                        })}
                    </div>
                </div>
            </div>
             <div className="mt-4 text-xs text-text-secondary font-normal">
                <p>+8.2% vs mês passado (simulado)</p>
            </div>
        </div>
    );
};

export default React.memo(FinancialSummary);