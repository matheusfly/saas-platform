
import React, { useState, useEffect } from 'react';
import { Customer, CustomerSegment } from '../types';
import { segmentCustomers } from '../services/geminiService';
import { SkeletonCustomerSegmentation } from './common/SkeletonLoader';
import { IconUserGroup } from '../constants';

const CustomerSegmentation: React.FC<{ customers: Customer[] }> = ({ customers }) => {
    const [segments, setSegments] = useState<CustomerSegment[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchSegments = async () => {
            if (customers.length === 0) {
                setIsLoading(false);
                return;
            }
            setIsLoading(true);
            setError(null);
            try {
                const result = await segmentCustomers(customers);
                setSegments(result);
            } catch (e) {
                setError('Falha ao carregar a segmentação de clientes.');
                console.error(e);
            } finally {
                setIsLoading(false);
            }
        };
        fetchSegments();
    }, [customers]);

    if (isLoading) {
        return <SkeletonCustomerSegmentation />;
    }

    if (error) {
        return (
            <div className="bg-ui-surface p-6 rounded-2xl shadow-lg border border-border text-center text-text-error">
                <p>{error}</p>
            </div>
        );
    }

    return (
        <div className="bg-ui-surface p-6 rounded-2xl shadow-lg border border-border">
            <div className="flex items-center mb-4">
                <div className="bg-primary text-text-on-primary p-2 rounded-lg mr-3">
                    <IconUserGroup />
                </div>
                <h2 className="text-xl font-bold text-text-default">Segmentação de Clientes (IA)</h2>
            </div>
            {segments.length > 0 ? (
                <div className="space-y-4">
                    {segments.map((segment, index) => (
                        <div key={index} className="bg-ui-sidebar-surface p-4 rounded-lg">
                            <h3 className="font-bold text-success">{segment.segmentName}</h3>
                            <p className="text-sm text-text-secondary mt-1 mb-2">{segment.description}</p>
                            <div className="text-xs text-text-secondary flex items-center justify-between">
                                <span>
                                    <strong className="text-text-default">{segment.customerCount}</strong> clientes neste segmento
                                </span>
                                <div className="text-right italic">
                                    {segment.personas.slice(0, 2).join(', ')}{segment.personas.length > 2 ? '...' : ''}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                 <p className="text-center text-text-secondary py-4 text-sm">Não foi possível gerar segmentos.</p>
            )}
        </div>
    );
};

export default React.memo(CustomerSegmentation);