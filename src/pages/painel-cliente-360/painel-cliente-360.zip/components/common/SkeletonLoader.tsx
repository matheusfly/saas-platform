

import React from 'react';

export const SkeletonDivRow: React.FC = () => (
    <div className="flex items-center border-b border-border p-4 animate-pulse h-[76px]">
        <div className="flex items-center w-[35%]">
            <div className="w-10 h-10 rounded-full mr-4 bg-ui-sidebar-surface flex-shrink-0"></div>
            <div className="w-full">
                <div className="h-4 bg-ui-sidebar-surface rounded w-3/4 mb-1"></div>
                <div className="h-3 bg-ui-sidebar-surface rounded w-full"></div>
            </div>
        </div>
        <div className="w-[15%] px-4">
             <div className="h-6 bg-ui-sidebar-surface rounded w-20"></div>
        </div>
        <div className="w-[20%] px-4">
             <div className="h-4 bg-ui-sidebar-surface rounded w-24"></div>
        </div>
        <div className="w-[15%] px-4">
             <div className="h-4 bg-ui-sidebar-surface rounded w-28"></div>
        </div>
         <div className="w-[15%] flex justify-center">
             <div className="h-10 bg-ui-sidebar-surface rounded-full w-10"></div>
        </div>
    </div>
);


export const SkeletonDivTable: React.FC<{ rows?: number }> = ({ rows = 12 }) => {
    return (
        <div className="bg-ui-surface p-6 rounded-2xl shadow-lg border border-border">
            {Array.from({ length: rows }).map((_, index) => (
                <SkeletonDivRow key={index} />
            ))}
        </div>
    );
};

export const SkeletonFinancialSummary: React.FC = () => (
    <div className="bg-ui-surface p-6 rounded-2xl shadow-lg animate-pulse border border-border">
         <div className="flex justify-between items-start mb-4">
            <div>
                <div className="h-4 bg-ui-sidebar-surface rounded w-24 mb-2"></div>
                <div className="h-8 bg-ui-sidebar-surface rounded w-40"></div>
            </div>
            <div className="bg-ui-sidebar-surface rounded-full w-12 h-12"></div>
        </div>
         <div className="flex items-center text-sm mb-6">
             <div className="bg-ui-sidebar-surface p-2 rounded-lg mr-3 w-10 h-10"></div>
             <div className="w-full">
                <div className="h-4 bg-ui-sidebar-surface rounded w-28 mb-1"></div>
                <div className="h-3 bg-ui-sidebar-surface rounded w-48"></div>
             </div>
        </div>
         <div>
            <div className="h-4 bg-ui-sidebar-surface rounded w-32 mb-3"></div>
            <div className="space-y-3">
                <div className="h-5 bg-ui-sidebar-surface rounded-lg w-full"></div>
                <div className="h-5 bg-ui-sidebar-surface rounded-lg w-full"></div>
                <div className="h-5 bg-ui-sidebar-surface rounded-lg w-full"></div>
            </div>
        </div>
    </div>
);

export const SkeletonChart: React.FC = () => (
     <div className="bg-ui-surface p-6 rounded-2xl shadow-lg animate-pulse border border-border">
        <div className="flex items-center mb-4">
            <div className="bg-ui-sidebar-surface p-2 rounded-lg mr-3 w-10 h-10"></div>
            <div className="h-6 bg-ui-sidebar-surface rounded w-40"></div>
        </div>
        <div className="space-y-4 mt-2">
            <div className="h-10 bg-ui-sidebar-surface rounded-lg w-full"></div>
            <div className="h-10 bg-ui-sidebar-surface rounded-lg w-full"></div>
            <div className="h-10 bg-ui-sidebar-surface rounded-lg w-full"></div>
            <div className="h-10 bg-ui-sidebar-surface rounded-lg w-full"></div>
        </div>
    </div>
);

export const SkeletonCustomerSegmentation: React.FC = () => (
    <div className="bg-ui-surface p-6 rounded-2xl shadow-lg animate-pulse border border-border">
        <div className="flex items-center mb-4">
            <div className="bg-ui-sidebar-surface p-2 rounded-lg mr-3 w-10 h-10"></div>
            <div className="h-6 bg-ui-sidebar-surface rounded w-3/4"></div>
        </div>
        <div className="space-y-4">
            <div className="bg-ui-sidebar-surface p-4 rounded-lg">
                <div className="h-5 bg-border rounded w-1/3 mb-2"></div>
                <div className="h-3 bg-border rounded w-full mb-3"></div>
                <div className="h-3 bg-border rounded w-1/2"></div>
            </div>
            <div className="bg-ui-sidebar-surface p-4 rounded-lg">
                <div className="h-5 bg-border rounded w-1/2 mb-2"></div>
                <div className="h-3 bg-border rounded w-4/5 mb-3"></div>
                <div className="h-3 bg-border rounded w-2/3"></div>
            </div>
        </div>
    </div>
);

export const SkeletonChurnPrediction: React.FC = () => (
    <div className="bg-ui-surface p-6 rounded-2xl shadow-lg animate-pulse border border-border">
        <div className="flex items-center mb-4">
            <div className="bg-ui-sidebar-surface p-2 rounded-lg mr-3 w-10 h-10"></div>
            <div className="h-6 bg-ui-sidebar-surface rounded w-2/3"></div>
        </div>
        <div className="space-y-3">
            {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="flex items-center space-x-3 p-2">
                    <div className="w-9 h-9 rounded-full bg-ui-sidebar-surface"></div>
                    <div className="flex-grow">
                        <div className="h-4 bg-ui-sidebar-surface rounded w-1/2 mb-2"></div>
                        <div className="h-3 bg-ui-sidebar-surface rounded w-full"></div>
                    </div>
                </div>
            ))}
        </div>
    </div>
);