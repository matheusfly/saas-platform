
import React, { useState, useEffect } from 'react';
import { Customer, ChurnPrediction as ChurnPredictionType } from '../types';
import { predictChurningCustomers } from '../services/geminiService';
import { SkeletonChurnPrediction } from './common/SkeletonLoader';
import { IconUserMinus } from '../constants';

const ChurnPrediction: React.FC<{ customers: Customer[] }> = ({ customers }) => {
    const [predictions, setPredictions] = useState<ChurnPredictionType[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchPredictions = async () => {
            if (customers.length === 0) {
                setIsLoading(false);
                return;
            }
            setIsLoading(true);
            setError(null);
            try {
                const result = await predictChurningCustomers(customers);
                setPredictions(result.sort((a,b) => b.churnProbability - a.churnProbability));
            } catch (e) {
                setError('Falha ao prever risco de churn.');
                console.error(e);
            } finally {
                setIsLoading(false);
            }
        };
        fetchPredictions();
    }, [customers]);

    if (isLoading) {
        return <SkeletonChurnPrediction />;
    }

    if (error) {
        return (
            <div className="bg-ui-surface p-6 rounded-2xl shadow-lg border border-border text-center text-text-error">
                <p>{error}</p>
            </div>
        );
    }

    return (
        <div className="bg-ui-surface p-6 rounded-2xl shadow-lg border border-border">
            <div className="flex items-center mb-4">
                 <div className="bg-primary text-text-on-primary p-2 rounded-lg mr-3">
                    <IconUserMinus />
                </div>
                <h2 className="text-xl font-bold text-text-default">Previsão de Churn (IA)</h2>
            </div>
             {predictions.length > 0 ? (
                <ul className="space-y-3">
                    {predictions.map(pred => (
                        <li key={pred.customerId} className="flex items-center space-x-3 p-2 rounded-lg bg-ui-sidebar-surface/60">
                            <img src={pred.customerAvatar} alt={pred.customerName} className="w-9 h-9 rounded-full object-cover" />
                            <div className="flex-grow">
                                <p className="font-semibold text-text-default text-sm">{pred.customerName}</p>
                                <div className="flex items-center gap-2 mt-1">
                                    <div className="w-full bg-border rounded-full h-1.5">
                                        <div 
                                            className="bg-text-decrease h-1.5 rounded-full" 
                                            style={{ width: `${pred.churnProbability * 100}%` }}
                                        ></div>
                                    </div>
                                    <span className="text-xs font-bold text-text-decrease w-10 text-right">
                                        {Math.round(pred.churnProbability * 100)}%
                                    </span>
                                </div>
                            </div>
                        </li>
                    ))}
                </ul>
            ) : (
                <p className="text-center text-text-secondary py-4 text-sm">Nenhum risco de churn significativo detectado.</p>
            )}
        </div>
    );
};

export default React.memo(ChurnPrediction);