

import React, { useState, useMemo, useCallback } from 'react';
import CustomerTable from './CustomerTable';
import DataManagement from './DataManagement';
import CustomerStatusChart from './CustomerStatusChart';
import RecentSignups from './RecentSignups';
import StrategicInsights from './StrategicInsights';
import FinancialSummary from './FinancialSummary';
import { Customer, CustomerStatus } from '../types';
import { useData } from '../contexts/DataContext';
import ErrorDisplay from './common/ErrorDisplay';
import { SkeletonChart, SkeletonFinancialSummary, SkeletonDivTable } from './common/SkeletonLoader';
import { IconSparkles } from '../constants';
import CustomerSegmentation from './CustomerSegmentation';
import ChurnPrediction from './ChurnPrediction';

type Tab = 'overview' | 'ai-insights' | 'data';

interface DashboardPageProps {
    searchedCustomers: Customer[];
    loading: boolean;
    error: string | null;
    onRetry: () => void;
}

const DashboardPage: React.FC<DashboardPageProps> = ({ searchedCustomers, loading, error, onRetry }) => {
    const { allCustomers, addNewCustomers: onAddNewCustomers } = useData();
    const [activeTab, setActiveTab] = useState<Tab>('overview');
    const [statusFilter, setStatusFilter] = useState<CustomerStatus | 'all'>('all');

    const dashboardStats = useMemo(() => {
        if (!allCustomers || allCustomers.length === 0) {
            return {
                totalCustomers: '0',
                newSignups: '0',
                churnRate: '0,0%',
            };
        }
        const totalCustomers = allCustomers.length;
        const newSignups = allCustomers.filter(c => c.status === CustomerStatus.New).length;
        const churned = allCustomers.filter(c => c.status === CustomerStatus.Churned).length;
        const churnRate = totalCustomers > 0 ? ((churned / totalCustomers) * 100).toFixed(1) : '0.0';
        
        return {
            totalCustomers: totalCustomers.toLocaleString('pt-BR'),
            newSignups: newSignups.toLocaleString('pt-BR'),
            churnRate: `${churnRate.replace('.',',')}%`,
        };
    }, [allCustomers]);

    const handleStatusFilterChange = useCallback((status: CustomerStatus | 'all') => {
        setStatusFilter(prev => prev === status ? 'all' : status); // Toggle filter
    }, []);
    
    const statusFilteredCustomers = useMemo(() => {
        if (statusFilter === 'all') {
            return searchedCustomers;
        }
        return searchedCustomers.filter(c => c.status === statusFilter);
    }, [searchedCustomers, statusFilter]);
    
    const renderOverviewTab = () => (
         <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* --- Main Column --- */}
            <div className="lg:col-span-2">
                {loading ? 
                    <SkeletonDivTable rows={12} /> : 
                    <CustomerTable 
                        customers={statusFilteredCustomers} 
                        loading={loading}
                        stats={dashboardStats.totalCustomers}
                    />
                }
            </div>

            {/* --- Side Column --- */}
            <div className="flex flex-col gap-6">
                 {loading ? (
                    <>
                       <SkeletonFinancialSummary />
                       <SkeletonChart />
                       <SkeletonChart />
                    </>
                ) : (
                    <>
                       <FinancialSummary customers={allCustomers} />
                       <CustomerStatusChart 
                            customers={allCustomers}
                            onStatusClick={handleStatusFilterChange}
                            activeStatus={statusFilter}
                            stats={dashboardStats.churnRate}
                        />
                       <RecentSignups customers={allCustomers} stats={dashboardStats.newSignups} />
                    </>
                )}
            </div>
        </div>
    );

    const renderAiInsightsTab = () => (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
            {/* Left Column for Strategic Insights */}
            <div className="lg:col-span-1">
                <StrategicInsights customers={allCustomers} />
            </div>
            {/* Right Column for New AI Widgets */}
            <div className="lg:col-span-1 flex flex-col gap-6">
                <CustomerSegmentation customers={allCustomers} />
                <ChurnPrediction customers={allCustomers} />
            </div>
        </div>
    );


    const renderTabContent = () => {
        if (error && !loading) {
            return <div className="mt-10"><ErrorDisplay message={error} onRetry={onRetry} /></div>;
        }

        switch (activeTab) {
            case 'overview':
                return renderOverviewTab();
            case 'ai-insights':
                return renderAiInsightsTab();
            case 'data':
                return <DataManagement onAddNewCustomers={onAddNewCustomers} allCustomers={allCustomers} />;
            default:
                return null;
        }
    };
    
    const getTabClass = (tabName: Tab) => {
        return `px-1 py-3 font-semibold transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary border-b-2 flex items-center ${
            activeTab === tabName
            ? 'text-success border-success'
            : 'text-text-secondary hover:text-text-default border-transparent'
        }`;
    }

    return (
        <div>
            <div className="border-b border-border mb-6">
                <nav className="flex space-x-8">
                    <button onClick={() => setActiveTab('overview')} className={getTabClass('overview')}>
                        Visão Geral
                    </button>
                    <button onClick={() => setActiveTab('ai-insights')} className={getTabClass('ai-insights')}>
                        <IconSparkles /> AI Insights
                    </button>
                    <button onClick={() => setActiveTab('data')} className={getTabClass('data')}>
                        Gerenciamento de Dados
                    </button>
                </nav>
            </div>
            
            {renderTabContent()}
        </div>
    );
};

export default DashboardPage;