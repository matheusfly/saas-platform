# Interactive Business Intelligence Dashboard

This project is a sophisticated, data-driven Business Intelligence (BI) dashboard built with React, TypeScript, and Tailwind CSS. It provides a comprehensive suite of tools for visualizing and analyzing business data, including sales funnels, financial performance, and team productivity. A key feature of this dashboard is its integration with the Google Gemini API to generate actionable, AI-powered insights and provide an interactive business assistant.

## ✨ Features

- **Multi-Page Dashboard**: Separate, detailed pages for different business areas: Commercial, Sales, Opportunities, Conversions, Financial, Strategic, and Productivity.
- **Advanced & Predictive Analytics**: Dedicated pages for deep-dive analysis and future performance forecasting.
- **Interactive Visualizations**: A rich library of charts and graphs built with **Recharts** and **D3.js**, including funnels, heatmaps, radar charts, and more.
- **Dynamic Filtering**: Easily filter the entire dashboard's data by predefined date ranges (e.g., Today, 7 Days, 30 Days, etc.).
- **AI-Powered Insights**:
  - **Insights Panel**: Generates a concise summary and actionable insights based on the current data view.
  - **Business Assistant**: An interactive chat assistant, powered by the Gemini API, that can answer natural language questions about the dashboard data.
- **Responsive Design**: A clean, modern UI that adapts to different screen sizes.
- **Component-Based Architecture**: Built with reusable React components for maintainability and scalability.

---

## 📂 Project Structure

The project is organized into several key directories:

```
/
├── public/
├── src/
│   ├── components/
│   │   ├── charts/         # Recharts & D3 chart components
│   │   ├── ... (page and UI components)
│   ├── services/
│   │   ├── apiClient.ts      # NEW: API abstraction layer
│   │   ├── dataService.ts    # Core data processing (acts as mock API)
│   │   ├── geminiService.ts  # Handles communication with Google Gemini API
│   │   └── processedData.ts  # Simulates a raw database source
│   ├── App.tsx             # Main application component (routing & state)
│   ├── index.tsx           # React application entry point
│   └── types.ts            # TypeScript type definitions
├── index.html              # Main HTML file
└── README.md               # This file
```

---

## 🚀 Preparing for Production: Backend Integration

The application's architecture has been intentionally designed to make the transition from a mock data setup to a live production backend as seamless as possible. This is achieved through a dedicated API abstraction layer and robust asynchronous state management.

### Data Flow & API Abstraction

All data fetching is centralized in `services/apiClient.ts`. Components no longer access the data-processing logic (`dataService.ts`) directly. This abstraction means that to switch to a real backend, you only need to modify the `apiClient.ts` file.

```mermaid
graph TD
    subgraph "React Components"
        A[App.tsx]
    end

    subgraph "Services Layer"
        B(apiClient.ts <br> <i>fetchDataFromApi()</i>)
    end
    
    subgraph "Data Source (Switchable)"
        C[dataService.ts <br> <b>(Current Mock API)</b>]
        D(<i>Real Backend API <br> e.g., /api/dashboard</i>)
    end

    A -- "1. Calls fetchDataFromApi(filters)" --> B;
    B -- "2. Fetches data" --> C;
    
    B -.-> D;

    style D fill:#fff,stroke:#333,stroke-width:2px,stroke-dasharray: 5 5
    style C fill:#ccf,stroke:#333,stroke-width:2px
```

### Enhanced State Management & Interactivity

The dashboard's interactivity is managed by a robust asynchronous state machine in `App.tsx`. This ensures the user always has clear feedback on the status of their data requests.

```mermaid
stateDiagram-v2
    [*] --> Loading: Initial App Load

    Loading: Fetching data... <br> (Shows spinner)
    Loading --> DisplayingData: Data fetched successfully
    Loading --> ShowingError: Data fetch fails
    
    DisplayingData: Dashboard is interactive
    
    state "User Interaction" as UI_Action {
        DisplayingData --> UI_Action: User clicks a filter
    }
    
    UI_Action --> Loading: onFilterChange() triggers data refetch

    ShowingError: Displays error message <br> with "Retry" button
    ShowingError --> Loading: User clicks "Retry"

```

### Step-by-Step Guide to Connect a Real Backend

Follow these steps to replace the mock data service with your live API.

#### Step 1: Prepare Your Backend API

First, ensure you have a backend endpoint that can accept filters (like `dateRange`) and returns a JSON object matching the `AllData` interface defined in `src/services/dataService.ts`.

**Example API Endpoint:** `GET /api/dashboard?dateRange=30d`

**Example JSON Response:**
```json
{
  "funnel": [
    { "stage": "Prospect", "value": 500, "label": "500" },
    // ...
  ],
  "kpis": {
    "totalRevenue": 150000,
    "conversionRate": 16.5,
    // ...
  },
  // ... all other data properties
}
```

#### Step 2: Update the API Client (`services/apiClient.ts`)

This is the only file you need to modify. Change its implementation to call your real API endpoint using `fetch` or a library like `axios`.

**Current `apiClient.ts` (Using Mock Data):**
```typescript
import { getAllData } from './dataService';
import type { AllData } from './dataService';
import type { FilterState } from '../types';

export const fetchDataFromApi = (filters: FilterState): Promise<AllData> => {
  return new Promise((resolve) => {
    setTimeout(async () => {
      const data = await getAllData(filters);
      resolve(data);
    }, 500); // Simulates network delay
  });
};
```

**Future `apiClient.ts` (Using a Real API):**
```typescript
// services/apiClient.ts
import type { AllData } from './dataService';
import type { FilterState } from '../types';

const API_BASE_URL = 'https://your-backend.com/api';

export const fetchDataFromApi = async (filters: FilterState): Promise<AllData> => {
  const { dateRange } = filters;
  const url = `${API_BASE_URL}/dashboard?dateRange=${dateRange}`;
  
  try {
    const response = await fetch(url);

    if (!response.ok) {
      // Throw an error with the status text to be caught in App.tsx
      throw new Error(`API request failed: ${response.statusText}`);
    }

    const data: AllData = await response.json();
    return data;
  } catch (error) {
    console.error("API Client Error:", error);
    // Re-throw the error to be handled by the UI layer
    throw error;
  }
};
```

#### Step 3: (Optional) Clean Up Mock Files

Once your application is successfully connected to the live backend, you can safely delete `services/dataService.ts` and `services/processedData.ts` to remove the mock data layer.

---

## 📊 Data Structures (`types.ts`)

All data schemas and type definitions are centralized in `types.ts`. This ensures type safety and a clear understanding of the data flowing through the application.

### Key Interfaces:

-   **`AllData`**: The primary data object returned by the `dataService`. It's a comprehensive structure containing all the data needed to render every chart and KPI on the dashboard.

    ```typescript
    export interface AllData {
        funnel: FunnelData[];
        leadEvolution: LeadEvolutionData[];
        revenueExpense: RevenueExpenseData[];
        cohort: CohortData[];
        kpis: {
            totalRevenue: number;
            conversionRate: number;
            averageLtv: number;
            // ... and many other KPIs
        };
        // ... and many other chart-specific data arrays
    }
    ```

-   **Chart-Specific Types**: Each chart has its own data type to ensure the correct data shape is passed.
    -   `FunnelData`: `{ stage: string; value: number; label: string; }`
    -   `RevenueExpenseData`: `{ date: string; revenue: number; expenses: number; net: number; }`
    -   `CohortData`: `{ cohort: string; size: number; values: { month: number; percentage: number }[]; }`
    -   ...and many others.

-   **`FilterState`**: Manages the state of the dashboard's filters.
    -   `{ dateRange: 'today' | '7d' | '30d' | '90d' | '12m' | 'all' | ... }`

---

## ⚙️ Core Functions & Services

The `services` directory contains the brain of the dashboard, handling all data manipulation and external API calls.

### `services/dataService.ts`

This is the most critical file for data processing. It simulates a data warehouse by taking raw data from `processedData.ts` and transforming it into the structured format required by the components.

-   **`getAllData(filters: FilterState): Promise<AllData>`**: The main function that orchestrates data processing.
    1.  It determines the `startDate` based on the selected `dateRange` filter.
    2.  It filters the raw fact tables (`FatoOportunidades`, `FatoFinanceiro`, etc.).
    3.  It calls numerous specialized `get...Data` helper functions (e.g., `getFunnelData`, `getRevenueExpenseData`, `getCohortData`) to aggregate and structure data for each specific chart.
    4.  It calculates all high-level Key Performance Indicators (KPIs).
    5.  Finally, it returns the complete `AllData` object.

### `services/geminiService.ts`

This service handles all interactions with the Google Gemini API.

-   **`generateInsights(data: AllData): Promise<string>`**:
    1.  Receives the current `AllData` object from the dashboard.
    2.  Simplifies the data into a more compact JSON format suitable for the AI model.
    3.  Constructs a detailed prompt instructing the AI to act as a business analyst and provide a summary and actionable insights based on the provided data.
    4.  Calls the `gemini-2.5-flash` model via `ai.models.generateContent`.
    5.  Returns the formatted text response from the AI.

---

## 🧩 Component Breakdown

The application is built using a modular component architecture.

### Main Components

-   **`App.tsx`**: The top-level component. It manages the global state, including the current page, filters, and the master `chartData` object. It fetches data via `dataService` whenever filters change and renders the appropriate page component.

-   **`Sidebar.tsx`**: The main navigation component on the left. It allows users to switch between different dashboard pages and can be collapsed to save space.

### Page Components

These components act as containers for a specific view, organizing various charts and KPIs.
-   `Dashboard.tsx`: The main "Commercial" landing page.
-   `FinancialPage.tsx`: Focuses on revenue, expenses, and cash flow.
-   `OpportunitiesPage.tsx`: Displays data about open and closed sales opportunities.
-   `AdvancedAnalyticsPage.tsx`: A dashboard with more complex, deep-dive visualizations.
-   `PredictiveAnalyticsPage.tsx`: Showcases forecasted data for key metrics like revenue and LTV.

### AI Components

-   **`InsightsPanel.tsx`**: A collapsible panel that uses `geminiService.generateInsights` to produce a static analysis of the current data view on demand.

-   **`BusinessAssistant.tsx`**: Provides an interactive chat experience.
    1.  It initializes a Gemini chat session with a `systemInstruction` that includes the current (simplified) dashboard data.
    2.  When the user sends a message, it streams the response from the Gemini API, providing a real-time, "typing" effect.

### Chart Components (`components/charts/`)

This directory contains all the data visualization components. The project uses a mix of libraries for flexibility.

-   **Recharts Components**: Most charts are built with Recharts, a composable charting library for React.
    -   `ConversionFunnelChart.tsx`: A vertical bar chart representing the sales funnel.
    -   `RevenueExpenseChart.tsx`: A composed chart showing revenue/expense bars and a net profit line.
    -   `UserPerformanceRadarChart.tsx`: A radar chart to compare multiple performance metrics across different team members.

-   **D3.js Components**: For more complex or custom visualizations, D3.js is used. A React component wraps the D3 logic, using a `useRef` to manage the SVG container.
    -   `CohortAnalysisChart.tsx`: A D3-powered heatmap to visualize user retention over time.
    -   `SalesCycleBoxPlot.tsx`: A box plot showing the distribution of the sales cycle duration for each team member.

---

## 🚀 Getting Started

### Prerequisites

-   Node.js (v18 or later)
-   An active Google Gemini API key.

### Installation & Setup

1.  **Clone the repository:**
    ```bash
    git clone <repository-url>
    cd <project-directory>
    ```

2.  **Install dependencies:**
    ```bash
    npm install
    ```

3.  **Set up Environment Variables:**
    The Gemini API requires an API key. You must provide this key as an environment variable. The application is hard-coded to read it from `process.env.API_KEY`. In a real development environment, you would create a `.env` file in the root of the project:

    ```
    # .env
    API_KEY="YOUR_GEMINI_API_KEY"
    ```
    *Note: This setup assumes a build tool (like Vite or Create React App) is configured to handle `.env` files. In this project's current configuration, the variable is expected to be globally available in the execution environment.*

### Running the Application

Once set up, you can run the development server:

```bash
npm run start
```

This will start the application, and you can access it at the local URL provided in your terminal.
