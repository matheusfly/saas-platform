import React from 'react';
import ChartCard from './ChartCard';
import InsightsPanel from './InsightsPanel';
import FilterControls from './FilterControls';
import BusinessAssistant from './BusinessAssistant';
import KeyMetricCard from './KeyMetricCard';
import ConversionFunnelChart from './charts/ConversionFunnelChart';
import LeadEvolutionChart from './charts/LeadEvolutionChart';
import LtvPermanenceChart from './charts/LtvPermanenceChart';
import CheckInChart from './charts/CheckInChart';
import { FilterState } from '../types';
import type { AllData } from '../services/dataService';

interface DashboardProps {
    filters: FilterState;
    onFilterChange: (newFilters: FilterState) => void;
    chartData: AllData;
}

const Dashboard: React.FC<DashboardProps> = ({ filters, onFilterChange, chartData }) => {
  const { kpis, funnel, ltv, leadEvolution, checkIn } = chartData;
  return (
    <div className="space-y-6">
      {/* Top Row: AI and KPI Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        <InsightsPanel chartData={chartData} />
        <BusinessAssistant data={chartData} />
      </div>

      {/* Filters */}
      <FilterControls filters={filters} onFilterChange={onFilterChange} />
      
      {/* Second Row: High-Level KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        <KeyMetricCard title="Receita Total" value={`R$ ${kpis.totalRevenue.toLocaleString('pt-BR')}`} description="Receita no período selecionado" />
        <KeyMetricCard title="Novos Clientes" value={kpis.newClientCount.toString()} description="Clientes que se inscreveram no período" />
        <KeyMetricCard title="LTV Médio" value={`R$ ${kpis.averageLtv.toFixed(0)}`} description="Valor médio do cliente" />
        <KeyMetricCard title="Taxa de Conversão" value={`${kpis.conversionRate.toFixed(1)}%`} description="De prospect para cliente" />
      </div>

      {/* Third Row: Acquisition Story */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <ChartCard title="Funil de Conversão" chartClassName="h-[450px]">
            <ConversionFunnelChart data={funnel} />
          </ChartCard>
        </div>
        <ChartCard title="LTV por Contrato" chartClassName="h-[450px]">
          <LtvPermanenceChart data={ltv} />
        </ChartCard>
      </div>
      
       {/* Fourth Row: Evolution and Engagement */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ChartCard title="Evolução de Leads/Clientes">
            <LeadEvolutionChart data={leadEvolution} />
          </ChartCard>
          <ChartCard title="Frequência de Check-in vs. Valor Pago">
            <CheckInChart data={checkIn} />
        </ChartCard>
      </div>
    </div>
  );
};

export default Dashboard;
